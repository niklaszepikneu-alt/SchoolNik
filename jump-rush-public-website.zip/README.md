# Jump Rush – öffentliche Website

Diese Version ist als statische Website für GitHub Pages, Netlify, Vercel oder einen normalen Webserver vorbereitet.

## Dateien
- `index.html` = öffentliche Startseite
- `game.html` = spielbare Game-Seite

## Veröffentlichung
Die beiden Dateien müssen im selben Verzeichnis auf einem Static-Hosting-Dienst liegen.
`index.html` ist automatisch die Startseite.

## Wichtig
Das Spiel lädt Phaser von jsDelivr. Für den aktuellen Prototyp braucht der Browser daher Internetzugang.

## Lokaler Test
Einfach `index.html` öffnen. Für eine möglichst zuverlässige lokale Vorschau kann auch ein einfacher lokaler Webserver verwendet werden.
